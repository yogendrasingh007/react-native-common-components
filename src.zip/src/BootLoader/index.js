import InternsProvider from './InternsProvider';
import AppRoot from './AppRoot';

module.exports = {
	InternsProvider,
	AppRoot
};
