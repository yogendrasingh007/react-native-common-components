import BaseComponent from './BaseComponent';

module.exports = {
	BaseComponent
};
