import { createStackNavigator, createAppContainer } from 'react-navigation';
import React from 'react';
import First from './First';
import Third from './Third';
const MainNavigator = createStackNavigator({
	Home: First,
	Profile: Third
});

const AppContainer = createAppContainer(MainNavigator);

export default class AppControlFlow extends React.Component {
	render() {
		return <AppContainer />;
	}
}
