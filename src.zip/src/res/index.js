import Images from './Images';
import Strings from './Strings';
import Theme from './Theme';

module.exports = {
	Images,
	Strings,
	Theme
};
