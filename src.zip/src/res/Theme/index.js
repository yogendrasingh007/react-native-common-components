import Colors from './Colors';
import Fonts from './Fonts';
import ViewStyles from './ViewStyles';

module.exports = {
	Colors,
	Fonts,
	ViewStyles
};
