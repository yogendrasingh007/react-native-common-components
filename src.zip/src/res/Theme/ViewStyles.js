import Colors from './Colors';

module.exports = {
	container: {
		backgroundColor: Colors.BASE_BACKGROUND_COLOR,
		flex: 1
	}
};
