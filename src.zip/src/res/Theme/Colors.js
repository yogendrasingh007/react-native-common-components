const baseBackgroundColor = 'rgb(255, 244, 232)';

const Common = {
	BASE_BACKGROUND_COLOR: baseBackgroundColor,
	Text_Color: 'green'
};
module.exports = {
	...Common
};
