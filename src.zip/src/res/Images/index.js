const AppSpecific = {
	// splash: { source: require('./background/splash.png'), style: null }
};

module.exports = {
	...AppSpecific
};
