import AppStrings from './AppStrings';

module.exports = {
	...AppStrings
};
