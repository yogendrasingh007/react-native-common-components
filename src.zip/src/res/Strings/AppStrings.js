module.exports = {
	title: 'Common Components'
};
